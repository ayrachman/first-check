<?php
	error_reporting(E_ALL ^ E_DEPRECATED);
	$host = "localhost";
	$username = "id2581981_medicappweb";
	$password = "caca123";
	$database = "id2581981_medicappweb";
	//koneksi dan memilih database diserver
	$connection =mysql_connect($host,$username,$password) or Die ("Koneksi gagal, coba cek host,username atau password anda ... !");
	mysql_select_db($database,$connection) or die ("Koneksi gagal, coba cek database atau konfigurasi koneksi ... !");
	
	/* $host = "localhost";
	$username = "root";
	$password = "";
	$database = "ujikom";
	//koneksi dan memilih database diserver
	$connection =mysql_connect($host,$username,$password) or Die ("Koneksi gagal, coba cek host,username atau password anda ... !");
	mysql_select_db($database,$connection) or die ("Koneksi gagal, coba cek database atau konfigurasi koneksi ... !"); */
?>
