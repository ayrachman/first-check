<?php
include "../db/config.php";
$id = $_POST['pasien_id'];
$nama_pasien = $_POST['nama_pasien'];
$tanggal_lahir = $_POST['tanggal_lahir'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$alamat = $_POST['alamat'];

mysql_query ("Insert into pasien values ('$id','$nama_pasien','$tanggal_lahir','$jenis_kelamin',
				'$alamat')");

header("location:listpasien.php?pesan=input");
?>