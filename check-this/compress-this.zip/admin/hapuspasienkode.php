<?php
include "../db/config.php";
$id = $_GET['pasien_id'];
mysql_query("Delete from pasien where pasien_id='$id'")or die(mysql_error());

header("location:listpasien.php?pesan=hapus");
?>