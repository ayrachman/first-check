<?php include "header.php"; ?>

<div id="page-wrapper" >
		  <div class="header"> 
                        <h1 class="page-header">
                             Form Edit Pasien
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="index.php">Home</a></li>
					  <li><a href="editpasien.php">Forms</a></li>
					  <li class="active">Data</li>
					</ol> 
									
		</div>
		
            <div id="page-inner"> 
			 <div class="row">
			 <div class="col-lg-12">
			 <div class="card">
                        <div class="card-action">
                            Formulir Pasien
                        </div>
                        <div class="card-content">
		<?php
			include "../db/config.php";
			$id = $_GET['pasien_id'];
			$query  = mysql_query("select * from pasien where pasien_id='$id'") or die(mysql_error());
			while ($data = mysql_fetch_array($query)){
		?>
    <form action="editpasienkode.php" method="POST" class="col s12">
      <div class="row">
        <div class="input-field col s6">
          <input type="text" name="pasien_id" class="span11" value="<?php echo $data['pasien_id'] ?>" readonly required>
        </div>
	  </div>
	  <div class="row">
        <div class="input-field col s6">
          <input type="text" name="nama_pasien" class="span11" value="<?php echo $data['nama_pasien'] ?>">
        </div>
	  </div>
      <div class="row">
        <div class="input-field col s6">
          <input type="text" name="tanggal_lahir" class="span11 datepicker" value="<?php echo $data['tanggal_lahir'] ?>">
        </div>
      </div>
      <div class="row"><div class="input-field col s6">
          <input type="text" name="jenis_kelamin" class="span11" value="<?php echo $data['jenis_kelamin'] ?>">
        </div>
      </div>
	  <div class="row">
        <div class="input-field col s6">
          <input type="text" name="alamat" class="span11" value="<?php echo $data['alamat'] ?>">
        </div>
      </div>
	  <div class="form-actions">
                <button type="submit" class="btn btn-success">Simpan</button>
				<button type="reset" class="btn btn-warning"><a href="listpasien.php">Batal</a></button>
      </div>
    </form>
	<?php } ?>
	<div class="clearBoth"></div>
  </div>
    </div>
 </div>	
	 </div> 
                <!-- /.col-lg-12 --> 
			<footer><p>All right reserved.by Ridho Ayudha Rachman</p></footer>
			</div>
             <!-- /. PAGE INNER  -->
            </div>
<?php include "footer.php"; ?>