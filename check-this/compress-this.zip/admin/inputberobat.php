<?php include "header.php"; ?>

<?php
include "../db/config.php"; // membuat id otomatis
// membaca kode terbesar
$query = "SELECT max(no_transaksi) as maxKode FROM berobat";
$hasil = mysql_query($query);
$data  = mysql_fetch_array($hasil);
$kodeBerobat = $data['maxKode'];

$noUrut = (int) substr($kodeBerobat, 3, 3);

$noUrut++;

$char = "TR";
$newID = $char . sprintf("%03s", $noUrut);
?>

<?php
$tgl = date ("Y-m-d"); // tanggal otomatis
?>
<div id="page-wrapper" >
		  <div class="header"> 
                        <h1 class="page-header">
                             Form Input Berobat
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="index.php">Home</a></li>
					  <li><a href="inputberobat.php">Forms</a></li>
					  <li class="active">Data</li>
					</ol> 
									
		</div>
		
            <div id="page-inner"> 
			 <div class="row">
			 <div class="col-lg-12">
			 <div class="card">
                        <div class="card-action">
                            Formulir Berobat
                        </div>
                        <div class="card-content">
    <form action="inputberobatkode.php" method="POST" class="col s12">
      <div class="row">
        <div class="input-field col s6">
		<label class="control-label">No Transaksi</label>
          <input type="text" placeholder="No Transaksi" name="no_transaksi" class="validate" value="<?php echo $newID; ?>" readonly required>
        </div>
	  </div>
	  <div class="row">
        <div class="input-field col s6">
          <select name="pasien_id" class="form-control">
					<option>Nama Pasien</option>
					<?php
						include "../db/config.php";
						$tampil = mysql_query("SELECT * FROM pasien");
						while ($r=mysql_fetch_array($tampil))
						{
							echo "<option value='$r[pasien_id]'>$r[nama_pasien]</option>";
						}
					?>
		  </select>
        </div>
	  </div>
      <div class="row">
        <div class="input-field col s6">
		<label class="control-label">Tanggal Berobat</label>
          <input type="text" placeholder="Tanggal Berobat" name="tanggal_berobat" class="validate" value="<?php echo $tgl; ?>" readonly required>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s6">
          <select name="dokter_id" class="form-control">
					<option>Nama Dokter</option>
					<?php
						include "../db/config.php";
						$tampil = mysql_query("SELECT * FROM dokter");
						while ($r=mysql_fetch_array($tampil))
						{
							echo "<option value='$r[dokter_id]'>$r[nama_dokter]</option>";
						}
					?>
		  </select>
        </div>
      </div>
	  <div class="row">
        <div class="input-field col s6">
          <input type="text" placeholder="Keluhan" name="keluhan" class="validate">
        </div>
      </div>
	  <div class="row">
        <div class="input-field col s6">
          <input type="text" placeholder="Biaya Adm" name="biaya_adm" class="validate">
        </div>
      </div>
	  <div class="form-actions">
                <button type="submit" class="btn btn-success">Simpan</button>
				<button type="reset" class="btn btn-warning">Batal</button>
      </div>
    </form>
	<div class="clearBoth"></div>
  </div>
    </div>
 </div>	
	 </div> 
                <!-- /.col-lg-12 --> 
			<footer><p>All right reserved.by Ridho Ayudha Rachman</p></footer>
			</div>
             <!-- /. PAGE INNER  -->
            </div>
<?php include "footer.php"; ?>