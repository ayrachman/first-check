<?php 
include 'header.php';
?>

<?php
$a = mysql_query("select * from berobat");
?>

<div id="page-wrapper">
		  <div class="header"> 
                        <h1 class="page-header">
                            Selamat Datang ! <small> Program Aplikasi Berbasis Web.</small>
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="#">Home</a></li>
					  <li><a href="#">Profile</a></li>
					  <li class="active">Data</li>
					</ol> 
									
		</div>
            <div id="page-inner"> 
			
			  <div class="row">
                    
                    <div class="col-md-12">
                    <div class="card">
                        <div class="card-action">
                         Hallo !
                        </div>        
                         <div class="card-content"> 
						 <p>Ini adalah program aplikasi berbasis web dengan bahasa pemrograman PHP.</p>
                           <div class="clearBoth"><br/></div>
						    
						 </div>
						 </div>
									
				 <footer><p>All right reserved by <strong>Ridho Ayudha Rachman</strong></p></footer>
				</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>

<?php 
include 'footer.php';

?>