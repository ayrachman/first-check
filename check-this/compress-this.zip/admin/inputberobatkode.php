<?php
include "../db/config.php";
$id = $_POST['no_transaksi'];
$pasien_id = $_POST['pasien_id'];
$tanggal_berobat = $_POST['tanggal_berobat'];
$dokter_id = $_POST['dokter_id'];
$keluhan = $_POST['keluhan'];
$biaya_adm = $_POST['biaya_adm'];

mysql_query ("Insert into berobat values ('$id','$pasien_id','$tanggal_berobat','$dokter_id',
				'$keluhan','$biaya_adm')");

header("location:listberobat.php?pesan=input");
?>