<?php 
include '../db/config.php';
$id = $_POST['dokter_id'];
$nama_dokter = $_POST['nama_dokter'];
$poli_id = $_POST['poli_id'];

mysql_query("UPDATE dokter SET nama_dokter='$nama_dokter', poli_id='$poli_id' where dokter_id='$id'");

header("location:listdokter.php?pesan=update");
?>