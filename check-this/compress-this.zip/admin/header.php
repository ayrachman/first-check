<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php 
	session_start();
	include '../db/config.php';
?>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Portofolio | Ridho Ayudha Rachman</title>
	
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link rel="stylesheet" href="../assets/materialize/css/materialize.min.css" media="screen,projection" />
    <!-- Bootstrap Styles-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
	<!-- Favicon-->
    <link rel="shortcut icon" href="../lock/img/favicon_re.ico">
    <!-- Morris Chart Styles-->
    <link href="../assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
    <!-- Custom Styles-->
	<link href="../assets/css/select2.css" rel="stylesheet" />
    <link href="../assets/css/custom-styles.css" rel="stylesheet" />
	<link rel="stylesheet" href="../assets/css/uniform.css" />
	<link rel="stylesheet" href="../assets/css/datepicker.css" />
	<link href="../bootstrap-datepicker/css/bootstrap-datepicker3.min.css" rel="stylesheet">
    <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="../assets/js/Lightweight-Chart/cssCharts.css"> 
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand waves-effect waves-dark" href="index.php"><i class="large material-icons"></i> <strong>Medical App Web</strong></a>
				
		<div id="sideNav" href=""><i class="material-icons dp48">toc</i></div>
            </div>

            <ul class="nav navbar-top-links navbar-right">
				  <li><a class="dropdown-button waves-effect waves-dark" href="#!" data-activates="dropdown1"><i class="fa fa-user fa-fw"></i> <b>Hallo, <?php echo $_SESSION['username'] ?> !</b> <i class="material-icons right">arrow_drop_down</i></a></li>
            </ul>
        </nav>
		<!-- Dropdown Structure -->
<ul id="dropdown1" class="dropdown-content">
<li><a href="../logout.php"><i class="fa fa-sign-out fa-fw"></i> Keluar, <?php echo $_SESSION['username'] ?></a>
</li>
</ul> 
	   <!--/. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <a class="active-menu waves-effect waves-dark" href="index.php"><i class="fa fa-dashboard"></i> Halaman Utama</a>
                    </li>
					
					<li>
                        <a href="#" class="waves-effect waves-dark"><i class="fa fa-sitemap"></i> Menu Form<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="inputberobat.php">Form Berobat</a>
                            </li>
                            <li>
                                <a href="inputdokter.php">Form Dokter</a>
                            </li>
							<li>
                                <a href="inputpasien.php">Form Pasien</a>
                            </li>
							<li>
                                <a href="inputpoli.php">Form Poli</a>
                            </li>
                        </ul>
                    </li>
					
					<li>
                        <a href="#" class="waves-effect waves-dark"><i class="fa fa-sitemap"></i> Daftar Tabel<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="listberobat.php">Data Berobat</a>
                            </li>
                            <li>
                                <a href="listdokter.php">Data Dokter</a>
                            </li>
							<li>
                                <a href="listpasien.php">Data Pasien</a>
                            </li>
							<li>
                                <a href="listpoli.php">Data Poli</a>
                            </li>
                        </ul>
                    </li>
                </ul>

            </div>

        </nav>
        <!-- /. NAV SIDE  -->
		<!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="../assets/js/jquery-1.10.2.js"></script>
	<script src="../jquery/jquery-2.1.4.min.js"></script>
	<script src="../bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
	<script src="../assets/js/jquery.min.js"></script> 
	<script src="../assets/js/jquery.ui.custom.js"></script> 
	<!-- Bootstrap Js -->
    <script src="../assets/js/bootstrap.min.js"></script>
	<script src="../assets/js/bootstrap-datepicker.js"></script> 
	<script src="../assets/materialize/js/materialize.min.js"></script>
	
    <!-- Metis Menu Js -->
		<script src="../assets/js/jquery.metisMenu.js"></script> 
	<!-- DATA TABLE SCRIPTS -->
    <script src="../assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="../assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
	<script type="text/javascript">
//datepicker
     $(document).ready(function () {
                $('.datepicker').datepicker({
                 //merubah format tanggal datepicker ke dd-mm-yyyy
                    format: 'yyyy-mm-dd',
                    autoclose: true
                });
            });
</script>
    <!-- Custom Js -->
    <script src="../assets/js/custom-scripts.js"></script> 