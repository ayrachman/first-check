<?php 
include '../db/config.php';
$id = $_POST['no_transaksi'];
$pasien_id = $_POST['pasien_id'];
$tanggal_berobat = $_POST['tanggal_berobat'];
$dokter_id = $_POST['dokter_id'];
$keluhan = $_POST['keluhan'];
$biaya_adm = $_POST['biaya_adm'];

mysql_query("UPDATE berobat SET pasien_id='$pasien_id', tanggal_berobat='$tanggal_berobat', 
			dokter_id='$dokter_id', keluhan='$keluhan', biaya_adm='$biaya_adm' where no_transaksi='$id'");

header("location:listberobat.php?pesan=update");
?>