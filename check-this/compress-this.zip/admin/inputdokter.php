<?php include "header.php"; ?>

<?php
include "../db/config.php"; // membuat id otomatis
// membaca kode terbesar
$query = "SELECT max(dokter_id) as maxKode FROM dokter";
$hasil = mysql_query($query);
$data  = mysql_fetch_array($hasil);
$kodeDokter = $data['maxKode'];

$noUrut = (int) substr($kodeDokter, 3, 3);

$noUrut++;

$char = "DK";
$newID = $char . sprintf("%03s", $noUrut);
?>
<div id="page-wrapper" >
		  <div class="header"> 
                        <h1 class="page-header">
                             Form Input Dokter
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="index.php">Home</a></li>
					  <li><a href="inputdokter.php">Forms</a></li>
					  <li class="active">Data</li>
					</ol> 
									
		</div>
		
            <div id="page-inner"> 
			 <div class="row">
			 <div class="col-lg-12">
			 <div class="card">
                        <div class="card-action">
                            Formulir Dokter
                        </div>
                        <div class="card-content">
    <form action="inputdokterkode.php" method="POST" class="col s12">
      <div class="row">
        <div class="input-field col s6">
          <input type="text" placeholder="Dokter ID" name="dokter_id" class="validate" value="<?php echo $newID; ?>" readonly required>
        </div>
	  </div>
	  <div class="row">
        <div class="input-field col s6">
          <input type="text" placeholder="Nama Dokter" name="nama_dokter" class="validate">
        </div>
	  </div>
      <div class="row">
        <div class="input-field col s6">
          <select name="poli_id" class="form-control">
					<option>Poli ID</option>
					<?php
						include "../db/config.php";
						$tampil = mysql_query("SELECT * FROM poli");
						while ($r=mysql_fetch_array($tampil))
						{
							echo "<option value='$r[poli_id]'>$r[nama_poli]</option>";
						}
					?>
		  </select>
        </div>
      </div>
	  <div class="form-actions">
                <button type="submit" class="btn btn-success">Simpan</button>
				<button type="reset" class="btn btn-warning">Batal</button>
      </div>
    </form>
	<div class="clearBoth"></div>
  </div>
    </div>
 </div>	
	 </div> 
                <!-- /.col-lg-12 --> 
			<footer><p>All right reserved.by Ridho Ayudha Rachman</p></footer>
			</div>
             <!-- /. PAGE INNER  -->
            </div>
<?php include "footer.php"; ?>