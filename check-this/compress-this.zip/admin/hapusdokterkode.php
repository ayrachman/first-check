<?php
include "../db/config.php";
$id = $_GET['dokter_id'];
mysql_query("Delete from dokter where dokter_id='$id'")or die(mysql_error());

header("location:listdokter.php?pesan=hapus");
?>