<?php
include "../db/config.php";
$id = $_GET['no_transaksi'];
mysql_query("Delete from berobat where no_transaksi='$id'")or die(mysql_error());

header("location:listberobat.php?pesan=hapus");
?>