<?php 
include '../db/config.php';
$id = $_POST['pasien_id'];
$nama_pasien = $_POST['nama_pasien'];
$tanggal_lahir = $_POST['tanggal_lahir'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$alamat = $_POST['alamat'];

mysql_query("UPDATE pasien SET nama_pasien='$nama_pasien', tanggal_lahir='$tanggal_lahir', 
			jenis_kelamin='$jenis_kelamin', alamat='$alamat' where pasien_id='$id'");

header("location:listpasien.php?pesan=update");
?>