<?php include "header.php"; ?>

<?php
include "../db/config.php"; // membuat id otomatis
// membaca kode terbesar
$query = "SELECT max(poli_id) as maxKode FROM poli";
$hasil = mysql_query($query);
$data  = mysql_fetch_array($hasil);
$kodeDokter = $data['maxKode'];

$noUrut = (int) substr($kodeDokter, 3, 3);

$noUrut++;

$char = "PL";
$newID = $char . sprintf("%03s", $noUrut);
?>
<div id="page-wrapper" >
		  <div class="header"> 
                        <h1 class="page-header">
                             Form Input Poli
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="index.php">Home</a></li>
					  <li><a href="inputpoli.php">Forms</a></li>
					  <li class="active">Data</li>
					</ol> 
									
		</div>
		
            <div id="page-inner"> 
			 <div class="row">
			 <div class="col-lg-12">
			 <div class="card">
                        <div class="card-action">
                            Formulir Poli
                        </div>
                        <div class="card-content">
    <form action="inputpolikode.php" method="POST" class="col s12">
      <div class="row">
        <div class="input-field col s6">
          <input type="text" placeholder="Poli ID" name="poli_id" class="validate" value="<?php echo $newID; ?>" readonly required>
        </div>
	  </div>
	  <div class="row">
        <div class="input-field col s6">
          <input type="text" placeholder="Nama Poli" name="nama_poli" class="validate">
        </div>
	  </div>
	  <div class="form-actions">
                <button type="submit" class="btn btn-success">Simpan</button>
				<button type="reset" class="btn btn-warning">Batal</button>
      </div>
    </form>
	<div class="clearBoth"></div>
  </div>
    </div>
 </div>	
	 </div> 
                <!-- /.col-lg-12 --> 
			<footer><p>All right reserved.by Ridho Ayudha Rachman</p></footer>
			</div>
             <!-- /. PAGE INNER  -->
            </div>
<?php include "footer.php"; ?>