<?php include "header.php"; ?>

<div id="page-wrapper" >
		  <div class="header"> 
                        <h1 class="page-header">
                             Form Edit Dokter
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="index.php">Home</a></li>
					  <li><a href="editdokter.php">Forms</a></li>
					  <li class="active">Data</li>
					</ol> 
									
		</div>
		
            <div id="page-inner"> 
			 <div class="row">
			 <div class="col-lg-12">
			 <div class="card">
                        <div class="card-action">
                            Formulir Dokter
                        </div>
                        <div class="card-content">
		<?php
			include "../db/config.php";
			$id = $_GET['dokter_id'];
			$query  = mysql_query("select * from dokter where dokter_id='$id'") or die(mysql_error());
			while ($data = mysql_fetch_array($query)){
		?>
    <form action="editdokterkode.php" method="POST" class="col s12">
      <div class="row">
        <div class="input-field col s6">
          <input type="text" placeholder="Dokter ID" name="dokter_id" class="validate" value="<?php echo $data['dokter_id'] ?>" readonly required>
        </div>
	  </div>
	  <div class="row">
        <div class="input-field col s6">
          <input type="text" placeholder="Nama Dokter" name="nama_dokter" class="validate" value="<?php echo $data['nama_dokter'] ?>">
        </div>
	  </div>
      <div class="row">
        <div class="input-field col s6">
          <input type="text" placeholder="Poli ID" name="poli_id" class="validate" value="<?php echo $data['poli_id'] ?>" readonly required>
        </div>
      </div>
	  <div class="form-actions">
                <button type="submit" class="btn btn-success">Simpan</button>
				<button type="reset" class="btn btn-warning"><a href="listdokter.php">Batal</a></button>
      </div>
    </form>
		<?php } ?>
	<div class="clearBoth"></div>
  </div>
    </div>
 </div>	
	 </div> 
                <!-- /.col-lg-12 --> 
			<footer><p>All right reserved.by Ridho Ayudha Rachman</p></footer>
			</div>
             <!-- /. PAGE INNER  -->
            </div>
<?php include "footer.php"; ?>