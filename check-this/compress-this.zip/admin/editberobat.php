<?php include "header.php"; ?>


<div id="page-wrapper" >
		  <div class="header"> 
                        <h1 class="page-header">
                             Form Edit Berobat
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="index.php">Home</a></li>
					  <li><a href="editberobat.php">Forms</a></li>
					  <li class="active">Data</li>
					</ol> 
									
		</div>
		
            <div id="page-inner"> 
			 <div class="row">
			 <div class="col-lg-12">
			 <div class="card">
                        <div class="card-action">
                            Formulir Berobat
                        </div>
                        <div class="card-content">
	<?php
			include "../db/config.php";
			$id = $_GET['no_transaksi'];
			$query  = mysql_query("select * from berobat where no_transaksi='$id'") or die(mysql_error());
			while ($data = mysql_fetch_array($query)){
	?>
    <form action="editberobatkode.php" method="POST" class="col s12">
      <div class="row">
        <div class="input-field col s6">
          <input type="text" name="no_transaksi" class="validate" value="<?php echo $data['no_transaksi'] ?>" readonly required>
        </div>
	  </div>
	  <div class="row">
        <div class="input-field col s6">
		  <input type="text" name="pasien_id" class="validate" value="<?php echo $data['pasien_id'] ?>" readonly required>
        </div>
	  </div>
      <div class="row">
        <div class="input-field col s6">
          <input type="text" name="tanggal_berobat" class="validate" value="<?php echo $data['tanggal_berobat'] ?>" readonly required>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s6">
          <input type="text" name="dokter_id" class="validate" value="<?php echo $data['dokter_id'] ?>" readonly required>
        </div>
      </div>
	  <div class="row">
        <div class="input-field col s6">
          <input type="text" name="keluhan" class="validate" value="<?php echo $data['keluhan'] ?>">
        </div>
      </div>
	  <div class="row">
        <div class="input-field col s6">
          <input type="text" name="biaya_adm" class="validate" value="<?php echo $data['biaya_adm'] ?>">
        </div>
      </div>
	  <div class="form-actions">
                <button type="submit" class="btn btn-success">Simpan</button>
				<button type="reset" class="btn btn-warning"><a href="listberobat.php">Batal</a></button>
      </div>
    </form>
	<?php } ?>
	<div class="clearBoth"></div>
  </div>
    </div>
 </div>	
	 </div> 
                <!-- /.col-lg-12 --> 
			<footer><p>All right reserved.by Ridho Ayudha Rachman</p></footer>
			</div>
             <!-- /. PAGE INNER  -->
            </div>
<?php include "footer.php"; ?>