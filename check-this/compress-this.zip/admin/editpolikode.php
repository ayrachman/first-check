<?php 
include '../db/config.php';
$id = $_POST['poli_id'];
$nama_poli = $_POST['nama_poli'];

mysql_query("UPDATE poli SET nama_poli='$nama_poli' where poli_id='$id'");

header("location:listpoli.php?pesan=update");
?>