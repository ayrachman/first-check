<?php
include "../db/config.php";
$id = $_GET['poli_id'];
mysql_query("Delete from poli where poli_id='$id'")or die(mysql_error());

header("location:listpoli.php?pesan=hapus");
?>