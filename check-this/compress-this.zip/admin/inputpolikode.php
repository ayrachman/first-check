<?php
include "../db/config.php";
$id = $_POST['poli_id'];
$nama_poli = $_POST['nama_poli'];

mysql_query ("Insert into poli values ('$id','$nama_poli')");

header("location:listpoli.php?pesan=input");
?>