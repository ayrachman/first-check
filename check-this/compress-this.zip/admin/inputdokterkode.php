<?php
include "../db/config.php";

$id = $_POST['dokter_id'];
$nama_dokter = $_POST['nama_dokter'];
$poli_id = $_POST['poli_id'];

mysql_query ("Insert into dokter values ('$id','$nama_dokter','$poli_id')");

header("location:listdokter.php?pesan=input");
?>