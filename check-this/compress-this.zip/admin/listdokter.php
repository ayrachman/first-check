<?php include "header.php"; ?>

<?php 
include "../db/config.php";
$per_hal=10;
$jumlah_record=mysql_query("SELECT COUNT(*) from dokter")or die (mysql_error());
$jum=mysql_result($jumlah_record, 0);
$halaman=ceil($jum / $per_hal);
$page = (isset($_GET['page'])) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $per_hal;
?>
<div id="page-wrapper" >
		  <div class="header"> 
                        <h1 class="page-header">
                            Tabel Dokter
                        </h1>
						<ol class="breadcrumb">
					  <li><a href="index.php">Home</a></li>
					  <li><a href="listdokter.php">Tables</a></li>
					  <li class="active">Data</li>
					</ol> 
									
		</div>
<div id="page-inner"> 
<?php
		if(isset ($_GET['pesan'])){ // menampilkan pesan bahwa data berhasil diinput
			$pesan = $_GET['pesan'];
			if ($pesan == "input")
				{
					echo "<div class='card-content'>
							<div class='alert alert-success'>
								<strong>Terima kasih !</strong> Data berhasil di input
							</div>
						  </div>";
				}
			elseif ($pesan == "update")
				{
					echo "<div class='card-content'>
							<div class='alert alert-warning'>
								<strong>Terima kasih !</strong> Data berhasil di update
							</div>
						  </div>";
				}
			elseif ($pesan == "hapus")
				{
					echo "<div class='card-content'>
							<div class='alert alert-danger'>
								<strong>Terima kasih !</strong> Data berhasil di hapus
							</div>
						  </div>";
				}
		}
?>
<div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="card">
                        <div class="card-action">
                             Data Dokter
                        </div>
                        <div class="card-content">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
											<th class="center">No</th>
											<th class="center">Dokter ID</th>
											<th class="center">Nama Dokter</th>
											<th class="center">Poli ID</th>
											<th class="center">Opsi</th>
										</tr>
								<?php
									include "../db/config.php";
									$query = mysql_query("SELECT * FROM dokter")or die (mysql_error());
									$nomor = 1;
									while ($data = mysql_fetch_array($query)){
								?>
                                    </thead>
                                    <tr>
										<td class="center"><?php echo $nomor++;?></td>
										<td class="center"><?php echo $data['dokter_id'];?></td>
										<td class="center"><?php echo $data['nama_dokter'];?></td>
										<td class="center"><?php echo $data['poli_id'];?></td>
											<td class="center">
												<div class="btn-group">
											  <button data-toggle="dropdown" class="btn btn-success dropdown-toggle">Opsi <span class="caret"></span></button>
											  <ul class="dropdown-menu">
												<li><a href="editdokter.php?dokter_id=<?php echo $data['dokter_id'];?>">Edit</a></li>
												<li><a href="hapusdokterkode.php?dokter_id=<?php echo $data['dokter_id'];?>">Hapus</a></li>
											  </ul>
											</div>
											</td>
									</tr>
								<?php } ?>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
</div>
</div>
<?php include "footer.php"; ?>